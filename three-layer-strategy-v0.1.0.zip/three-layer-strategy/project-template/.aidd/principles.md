# Project principles

1. Start from an observable outcome.
2. Choose human, assisted or agentic execution for each workflow step.
3. Keep current truth separate from proposed changes.
4. Bound permissions and context for autonomous work.
5. Prefer small, reversible increments.
6. Verify outcomes independently when risk justifies it.
7. Keep a human accountable for decisions and release.
8. Spend compute and attention deliberately.

Add project-specific non-negotiables below this line.
