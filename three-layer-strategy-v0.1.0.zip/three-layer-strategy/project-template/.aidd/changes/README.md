# Proposed and active changes

Each change has its own folder containing intent, assessment, spec, plan, tasks and verification. Use the framework CLI to generate the bundle.
