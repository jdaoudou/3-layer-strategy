# Current product truth

Store one folder per stable capability. Describe what the product does now, not its implementation history.

Example:

```text
specs/
└── search/
    └── spec.md
```
