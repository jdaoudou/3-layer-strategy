# Durable decisions

Store architectural and product decisions whose context should survive the change that introduced them.
